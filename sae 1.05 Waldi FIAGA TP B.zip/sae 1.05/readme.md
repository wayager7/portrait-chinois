# héberger le site web en local:

url:
https://etudiant.u-pem.fr/~waldi.fiaga/portrait-chinois/

1. Installez XAMPP sur apachefriends.org
2. Créez un dossier "portrait-chinois" dans htdocs
3. Déposez-y les fichiers du site web
4. Lancez le module apache depuis le panneau de contrôle XAMPP